def exibir(texto, lista):
    print(texto, lista)

def criaLista(num):
    return list(range(num))
