"""Crie um exercício que precise fazer uso da variável composta “conjunto”."""

"Crie um conjunto que armaze o quadrado dos números de zero a dez elevado"


quadrado = {x** 2 for x in range(0, 11)}
print(quadrado)
