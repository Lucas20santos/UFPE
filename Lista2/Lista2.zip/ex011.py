"""Escreva as características das variáveis compostas estudadas."""

"""
Listas são objetos mutáveis aonde ordem importa

tuplas são objetos imutáveis aonde a ordem importa

dicionário 

são objetos aonde aonde não é importante e as chaves podem ser string

set ou conjunto são objetos que não aceitam repetição de valor

"""
